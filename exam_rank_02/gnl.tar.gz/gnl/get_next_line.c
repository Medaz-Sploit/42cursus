/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   get_next_line.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mazoukni <mazoukni@student.1337.ma>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/10/26 05:44:55 by mazoukni          #+#    #+#             */
/*   Updated: 2021/11/04 09:53:01 by mazoukni         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "get_next_line.h"

int ft_strlen(char *str)
{
	int i;
	
	i = 0;
	if (!str)
		return (0);
	while (str[i])
		i++;
	return (i);
}

char *find_line_break(char *str)
{
	int i;

	i = 0;
	if (!str)
		return ("null");
	while(str[i])
	{
		if(str[i] == '\n')
			return (&str[i]);
		i++;
	}
	return ("null");
}

char *ft_join(char *str1, char *str2)
{
	char *new;
	int i;
	
	i = 0;
	if (!str1 || !str2)
		return(NULL);
	new = malloc(sizeof(char) * (ft_strlen(str1) + ft_strlen(str2) + 1));
	while (*str1)
		new[i++] = *str1++;
	while (*str2)
		new[i++] = *str2++;
	new[i] = '\0';
	return (new);
}

char *ft_substr(char *str, int start, size_t len)
{
	char *new;
	int i;

	i = 0;
	if (!str || len <= 0)
		return (NULL);
	new = malloc((len + 1) * sizeof(char));
	if (!new)
		return (NULL);
	while (len)
	{
		new[i++] = str[start++];
		len--;
	}
	new[i] = '\0';
	return (new);
}

char *purge_line_from_temp(char *line, char *temp)
{
	char *new_temp;

	if (!find_line_break(temp))
	{
		free (temp);
		return (NULL);
	}
	new_temp = ft_substr(temp, ft_strlen(line), ft_strlen(temp) - ft_strlen(line)); 
	free (temp);
	return (new_temp);
}

char *extract_line_from_temp(char *temp)
{
	char *line;

	if (find_line_break(temp))
		line = ft_substr(temp, 0, ft_strlen(temp) - ft_strlen(find_line_break(temp)) + 1);
	else
		line = ft_substr(temp, 0, ft_strlen(temp));
	return (line);
}

char *update_temp(char *buff, char *temp)
{
	char *new;

	if (!temp)
	{
		temp = malloc(1);
		temp[0] = '\0';
	}
	new = ft_join(temp, buff);
	free (temp);
	return (new);
}

char *read_to_temp(int fd, char *temp)
{
	char buff[BUFFER_SIZE + 1];
	int bytes;

	bytes = 1;
	while (!find_line_break(temp) && bytes > 0)
	{
		bytes = read(fd, buff, BUFFER_SIZE);
		if ((bytes == 0 && !temp) || bytes == -1)
			return (NULL);
		buff[bytes] = '\0';
		temp = update_temp(buff, temp);
	}
	return (temp);
}

char *get_next_line(int fd)
{
	char *line;
	static char *temp;

	line = NULL;
	if (fd < 0 || BUFFER_SIZE <= 0)
		return (0);
	temp = read_to_temp(fd, temp);
	line = extract_line_from_temp(temp);
	temp = purge_line_from_temp(line, temp);
	return (line);
}